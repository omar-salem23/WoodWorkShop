# Workshop lab YOLO labels

Class IDs: `0=pen`, `1=screwdriver`, `2=screw`. Image files are not included. Pair each label file with the image sharing its basename. Original HEIC frames were converted to JPG. Variant suffixes match the uploaded Drive folder: `__BrightnessContrast`, `__HorizontalFlip`, `__VerticalFlip`.

Training includes 48 source frames and their three supplied variants each. Validation and test labels are unaugmented. Only complete handled screwdrivers are tagged.
